<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Validate' );


	class TribeValidate extends Tribe__Validate {

	}
