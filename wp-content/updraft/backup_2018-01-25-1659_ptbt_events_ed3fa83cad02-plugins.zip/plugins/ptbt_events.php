<?php
	
/*
Plugin Name: PTBT Events Manager
Plugin URI: 
Description: Plugin for maintaining PTBT Events
Version: 1.0
Author: Toby Jayne
Author URI: 
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: ptbt_events_manager
*/

/* !0. TABLE OF CONTENTS */

/*

1. HOOKS
		1.1 - registers all our custom shortcodes
2. SHORTCODES
		2.1 - ptbte_register_shortcodes()
		2.2 - ptbte_form_shortcode()
3. FILTERS

4. EXTERNAL SCRIPTS

5. ACTIONS

6. HELPERS

7. CUSTOM POST TYPES

8. ADMIN PAGES

9. SETTINGS

10. MISCELLANEOUS

*/


/* !1. HOOKS */

// 1.1
// hint: registers all our custom shortcodes on init
add_action('init', 'ptbte_register_shortcodes');



/* !2. SHORTCODES */
// 2.1
// hint: registers all our custom shortcodes
function ptbte_register_shortcodes() {
	add_shortcode('ptbte_form', 'ptbte_form_shortcode');
}
// 2.2
// hint: returns a html string for a email capture form
function ptbte_form_shortcode( $args, $content="") {
	
	// setup our output variable - the form html 
	$output = '
	
		<div class="ptbte">
		
			<form id="ptbte_form" name="ptbte_form" class="ptbte-form" method="post">
			
				<p class="ptbte-input-container">
				
					<label>Your Name</label><br />
					<input type="text" name="ptbte_fname" placeholder="First Name" />
					<input type="text" name="ptbte_lname" placeholder="Last Name" />
				
				</p>
				
				<p class="ptbte-input-container">
				
					<label>Your Email</label><br />
					<input type="email" name="ptbte_email" placeholder="ex. you@email.com" />
				
				</p>';
				
				// including content in our form html if content is passed into the function
				if( strlen($content) ):
				
					$output .= '<div class="ptbte-content">'. wpautop($content) .'</div>';
				
				endif;
				
				// completing our form html
				$output .= '<p class="ptbte-input-container">
				
					<input type="submit" name="ptbte_submit" value="Sign Me Up!" />
				
				</p>
			
			</form>
		
		</div>
	
	';
	
	// return our results/html
	return $output;
	
}




/* !3. FILTERS */




/* !4. EXTERNAL SCRIPTS */




/* !5. ACTIONS */




/* !6. HELPERS */




/* !7. CUSTOM POST TYPES */




/* !8. ADMIN PAGES */




/* !9. SETTINGS */




/* !10. MISCELLANEOUS */



