<?php

/**
 * Class Tribe__Events__Importer__Featured_Image_Uploader
 *
 * An extension of the base class to implement further methods that might be needed.
 */
class Tribe__Events__Importer__Featured_Image_Uploader extends Tribe__Image__Uploader {
}