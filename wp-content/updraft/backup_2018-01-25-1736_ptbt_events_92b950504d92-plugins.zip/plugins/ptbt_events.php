<?php
	
/*
Plugin Name: PTBT Events Manager
Plugin URI: 
Description: Plugin for maintaining PTBT Events
Version: 1.0
Author: Toby Jayne
Author URI: 
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: ptbt_events_manager
*/

/* !0. TABLE OF CONTENTS */

/*

1. HOOKS
		1.1 - registers all our custom shortcodes
2. SHORTCODES
		2.1 - ptbte_register_shortcodes()
		2.2 - ptbte_form_shortcode()
3. FILTERS

4. EXTERNAL SCRIPTS

5. ACTIONS

6. HELPERS

7. CUSTOM POST TYPES

8. ADMIN PAGES

9. SETTINGS

10. MISCELLANEOUS

*/


/* !1. HOOKS */

// 1.1
// hint: registers all our custom shortcodes on init
add_action('init', 'ptbte_register_shortcodes');

// 1.2
// hint: register custom admin column headers
add_filter('manage_edit-ptbte_subscriber_columns','ptbte_subscriber_column_headers');
add_filter('manage_edit-ptbte_list_columns','ptbte_list_column_headers');

// 1.3
// hint: register custom admin column data
add_filter('manage_ptbte_subscriber_posts_custom_column','ptbte_subscriber_column_data',1,2);
add_action(
    'admin_head-edit.php',
    'ptbte_register_custom_admin_titles'
);

/* !2. SHORTCODES */
// 2.1
// hint: registers all our custom shortcodes
function ptbte_register_shortcodes() {
	add_shortcode('ptbte_form', 'ptbte_form_shortcode');
}
// 2.2
// hint: returns a html string for a email capture form
function ptbte_form_shortcode( $args, $content="") {
	
	// setup our output variable - the form html 
	$output = '
	
		<div class="ptbte">
		
			<form id="ptbte_form" name="ptbte_form" class="ptbte-form" method="post">
			
				<p class="ptbte-input-container">
				
					<label>Your Name</label><br />
					<input type="text" name="ptbte_fname" placeholder="First Name" />
					<input type="text" name="ptbte_lname" placeholder="Last Name" />
				
				</p>
				
				<p class="ptbte-input-container">
				
					<label>Your Email</label><br />
					<input type="email" name="ptbte_email" placeholder="ex. you@email.com" />
				
				</p>';
				
				// including content in our form html if content is passed into the function
				if( strlen($content) ):
				
					$output .= '<div class="ptbte-content">'. wpautop($content) .'</div>';
				
				endif;
				
				// completing our form html
				$output .= '<p class="ptbte-input-container">
				
					<input type="submit" name="ptbte_submit" value="Sign Me Up!" />
				
				</p>
			
			</form>
		
		</div>
	
	';
	
	// return our results/html
	return $output;
	
}




/* !3. FILTERS */

// 3.1
function ptbte_subscriber_column_headers( $columns ) {
	
	// creating custom column header data
	$columns = array(
		'cb'=>'<input type="checkbox" />',
		'title'=>__('Subscriber Name'),
		'email'=>__('Email Address'),	
	);
	
	// returning new columns
	return $columns;
	
}

// 3.2
function ptbte_subscriber_column_data( $column, $post_id ) {
	
	// setup our return text
	$output = '';
	
	switch( $column ) {
		
		case 'title':
			// get the custom name data
			$fname = get_field('ptbte_fname', $post_id );
			$lname = get_field('ptbte_lname', $post_id );
			$output .= $fname .' '. $lname;
			break;
		case 'email':
			// get the custom email data
			$email = get_field('ptbte_email', $post_id );
			$output .= $email;
			break;
		
	}
	
	// echo the output
	echo $output;
	
}

// 3.2.2
// hint: registers special custom admin title columns
function ptbte_register_custom_admin_titles() {
    add_filter(
        'the_title',
        'ptbte_custom_admin_titles',
        99,
        2
    );
}

// 3.2.3
// hint: handles custom admin title "title" column data for post types without titles
function ptbte_custom_admin_titles( $title, $post_id ) {
   
    global $post;
	
    $output = $title;
   
    if( isset($post->post_type) ):
                switch( $post->post_type ) {
                        case 'ptbte_subscriber':
	                            $fname = get_field('ptbte_fname', $post_id );
	                            $lname = get_field('ptbte_lname', $post_id );
	                            $output = $fname .' '. $lname;
	                            break;
                }
        endif;
   
    return $output;
}

// 3.3
function ptbte_list_column_headers( $columns ) {
	
	// creating custom column header data
	$columns = array(
		'cb'=>'<input type="checkbox" />',
		'title'=>__('List Name'),	
	);
	
	// returning new columns
	return $columns;
	
}

// 3.4
function ptbte_list_column_data( $column, $post_id ) {
	
	// setup our return text
	$output = '';
	
	switch( $column ) {
		
		case 'example':
			// get the custom name data
			//$fname = get_field('ptbte_fname', $post_id );
			//$lname = get_field('ptbte_lname', $post_id );
			//$output .= $fname .' '. $lname;
			break;
		
	}
	
	// echo the output
	echo $output;
	
}




/* !4. EXTERNAL SCRIPTS */




/* !5. ACTIONS */




/* !6. HELPERS */




/* !7. CUSTOM POST TYPES */




/* !8. ADMIN PAGES */




/* !9. SETTINGS */




/* !10. MISCELLANEOUS */



